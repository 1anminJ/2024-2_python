#### 아래 링크를 클릭해 한국복지패널데이터 파일을 다운로드하세요.

[Koweps_hpwc14_2019_beta2.sav](https://bit.ly/Koweps_hpwc14_2019_beta2)
